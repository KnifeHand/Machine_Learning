#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 12:12:29 2018

"""

# Demo file for Spyder Tutorial


def hello():
    """Print "Hello World" and return None.""" # documentation string By convention, and as they usually extend over multiple lines, they are enclosed by triple double quotes (""").
    print("Hello World")

# Main program starts here 
    
hello()